package com.harindra.iptvpro.vod

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import java.util.Locale

/**
 * Real Media3 Track Selection Manager for Dedicated VOD Playback.
 *
 * - Video Quality: Discovers ONLY genuine available video tracks from Media3 [Tracks].
 *   Never fabricates fake resolutions. Clearly distinguishes adaptive HLS/DASH multi-track
 *   streams from single-track progressive streams.
 * - Audio Tracks: Identifies language, codec, stereo/5.1/7.1 layout, and device support.
 *   Never forces unsupported codecs.
 * - Subtitles: Supports Off, embedded tracks, and attached external subtitle tracks.
 */
@OptIn(UnstableApi::class)
class VodTrackSelectionManager {

    data class QualityInspection(
        val options: List<VodQualityOption>,
        val isAdaptiveStream: Boolean,
        val currentResolutionLabel: String,
        val isAutoMode: Boolean,
        val fixedStreamReason: String
    )

    companion object {
        fun formatResolutionLabel(height: Int): String = when {
            height >= 2000 -> "2160p 4K"
            height >= 1350 -> "1440p QHD"
            height >= 1000 -> "1080p Full HD"
            height >= 680 -> "720p HD"
            height >= 540 -> "576p SD"
            height >= 450 -> "480p SD"
            height >= 320 -> "360p"
            height > 0 -> "${height}p"
            else -> "Standard"
        }

        fun formatLanguageDisplay(code: String?, fallbackLabel: String? = null): String {
            val cleanCode = code?.trim().orEmpty()
            val cleanLabel = fallbackLabel?.trim().orEmpty()
            if (cleanCode.isBlank() || cleanCode.equals("und", ignoreCase = true)) {
                return cleanLabel.ifBlank { "Original / Default" }
            }
            val locale = Locale.forLanguageTag(cleanCode)
            val display = locale.getDisplayLanguage(Locale.ENGLISH).trim()
            val resolved = if (display.isNotBlank() && !display.equals(cleanCode, ignoreCase = true)) {
                display.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ENGLISH) else it.toString() }
            } else {
                cleanCode.uppercase(Locale.ROOT)
            }
            return if (cleanLabel.isNotBlank() && !cleanLabel.equals(resolved, ignoreCase = true)) {
                "$resolved ($cleanLabel)"
            } else {
                resolved
            }
        }

        fun shortAudioCodec(mimeType: String?, codecs: String?): String {
            val m = mimeType.orEmpty().lowercase(Locale.ROOT)
            val c = codecs.orEmpty().lowercase(Locale.ROOT)
            return when {
                m.contains("eac3-joc") || c.contains("ec+3") -> "Dolby Atmos"
                m.contains("eac3") || c.contains("ec-3") -> "Dolby Digital+"
                m.contains("ac3") || c.contains("ac-3") -> "Dolby Digital"
                m.contains("mp4a") && (c.contains("40.5") || c.contains("40.29")) -> "HE-AAC"
                m.contains("mp4a") || m.contains("aac") -> "AAC"
                m.contains("opus") -> "Opus"
                m.contains("flac") -> "FLAC"
                m.contains("vnd.dts") -> "DTS"
                m.contains("truehd") -> "TrueHD"
                m.contains("mpeg") || m.contains("mp3") -> "MP3"
                m.contains("vorbis") -> "Vorbis"
                m.isNotBlank() -> m.substringAfter('/').uppercase(Locale.ROOT)
                else -> "Audio"
            }
        }

        fun channelLayoutLabel(channelCount: Int): String = when (channelCount) {
            1 -> "Mono 1.0"
            2 -> "Stereo 2.0"
            6 -> "5.1 Surround"
            8 -> "7.1 Surround"
            in 3..16 -> "${channelCount}ch"
            else -> ""
        }
    }

    fun inspectVideoQualities(player: ExoPlayer): QualityInspection {
        val tracks = player.currentTracks
        val params = player.trackSelectionParameters
        val hasManualOverride = params.overrides.values.any { it.type == C.TRACK_TYPE_VIDEO }

        val discovered = ArrayList<VodQualityOption>()
        var activeFormat: Format? = null
        val seenKeys = HashSet<String>()

        for ((gIdx, group) in tracks.groups.withIndex()) {
            if (group.type != C.TRACK_TYPE_VIDEO) continue
            for (tIdx in 0 until group.length) {
                val fmt = group.getTrackFormat(tIdx)
                val supported = group.isTrackSupported(tIdx)
                val selected = group.isTrackSelected(tIdx)
                if (selected) activeFormat = fmt
                if (!supported) continue
                val h = fmt.height
                val w = fmt.width
                val br = fmt.bitrate
                val dedupeKey = "${h}_${br / 250_000}"
                if (h > 0 && seenKeys.add(dedupeKey)) {
                    discovered.add(
                        VodQualityOption(
                            id = "v_${gIdx}_${tIdx}",
                            label = formatResolutionLabel(h),
                            height = h,
                            width = w.coerceAtLeast(0),
                            bitrateBps = br.coerceAtLeast(0),
                            groupIndex = gIdx,
                            trackIndex = tIdx,
                            isAuto = false,
                            isSelected = hasManualOverride && selected,
                            isAvailable = true
                        )
                    )
                }
            }
        }

        val sortedQualities = discovered.sortedWith(
            compareByDescending<VodQualityOption> { it.height }.thenByDescending { it.bitrateBps }
        )
        val isAdaptive = sortedQualities.size > 1
        val activeHeight = activeFormat?.height ?: player.videoFormat?.height ?: 0
        val currentResLabel = if (activeHeight > 0) formatResolutionLabel(activeHeight) else "Auto"
        val autoOption = VodQualityOption(
            id = "v_auto",
            label = if (activeHeight > 0) "Auto ($currentResLabel)" else "Auto (Adaptive)",
            height = activeHeight,
            width = activeFormat?.width ?: 0,
            bitrateBps = activeFormat?.bitrate ?: 0,
            groupIndex = -1,
            trackIndex = -1,
            isAuto = true,
            isSelected = !hasManualOverride,
            isAvailable = true
        )

        val options = ArrayList<VodQualityOption>(sortedQualities.size + 1)
        options.add(autoOption)
        options.addAll(sortedQualities)

        val fixedReason = if (!isAdaptive) {
            if (activeHeight > 0) {
                "Fixed single-track source ($currentResLabel) — provider stream does not include multiple quality levels."
            } else {
                "Fixed single-track source — provider stream provides only one video representation."
            }
        } else {
            ""
        }

        return QualityInspection(
            options = options,
            isAdaptiveStream = isAdaptive,
            currentResolutionLabel = if (!hasManualOverride) "Auto • $currentResLabel" else currentResLabel,
            isAutoMode = !hasManualOverride,
            fixedStreamReason = fixedReason
        )
    }

    fun selectVideoQuality(player: ExoPlayer, option: VodQualityOption): Boolean {
        val builder = player.trackSelectionParameters.buildUpon()
        if (option.isAuto || option.groupIndex < 0) {
            builder.clearOverridesOfType(C.TRACK_TYPE_VIDEO)
            builder.setMaxVideoSize(Int.MAX_VALUE, Int.MAX_VALUE)
            player.trackSelectionParameters = builder.build()
            return true
        }
        val groups = player.currentTracks.groups
        val group = groups.getOrNull(option.groupIndex) ?: return false
        if (group.type != C.TRACK_TYPE_VIDEO || option.trackIndex !in 0 until group.length) return false
        if (!group.isTrackSupported(option.trackIndex)) return false
        builder.clearOverridesOfType(C.TRACK_TYPE_VIDEO)
        builder.setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, listOf(option.trackIndex)))
        player.trackSelectionParameters = builder.build()
        return true
    }

    fun applyPreferredQualityByLabel(player: ExoPlayer, preferredLabel: String) {
        val clean = preferredLabel.trim().uppercase(Locale.ROOT)
        if (clean.isEmpty() || clean == "AUTO") {
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                .setMaxVideoSize(Int.MAX_VALUE, Int.MAX_VALUE)
                .build()
            return
        }
        val targetHeight = when {
            clean.contains("2160") || clean.contains("4K") -> 2160
            clean.contains("1440") -> 1440
            clean.contains("1080") -> 1080
            clean.contains("720") -> 720
            clean.contains("576") -> 576
            clean.contains("480") -> 480
            clean.contains("360") -> 360
            else -> return
        }
        val inspection = inspectVideoQualities(player)
        if (!inspection.isAdaptiveStream) return
        val match = inspection.options
            .filter { !it.isAuto && it.isAvailable && it.height > 0 }
            .minByOrNull { kotlin.math.abs(it.height - targetHeight) }
        if (match != null) {
            selectVideoQuality(player, match)
        }
    }

    fun inspectAudioTracks(player: ExoPlayer): List<VodAudioTrackOption> {
        val tracks = player.currentTracks
        val hasManualOverride = player.trackSelectionParameters.overrides.values.any { it.type == C.TRACK_TYPE_AUDIO }
        val result = ArrayList<VodAudioTrackOption>()

        result.add(
            VodAudioTrackOption(
                id = "a_auto",
                label = "Auto / Original Language",
                languageCode = "original",
                languageDisplay = "Original",
                codecName = "",
                channelLayout = "",
                channelCount = 0,
                bitrateBps = 0,
                groupIndex = -1,
                trackIndex = -1,
                isAuto = true,
                isSupported = true,
                isSelected = !hasManualOverride
            )
        )

        var counter = 0
        for ((gIdx, group) in tracks.groups.withIndex()) {
            if (group.type != C.TRACK_TYPE_AUDIO) continue
            for (tIdx in 0 until group.length) {
                val fmt = group.getTrackFormat(tIdx)
                val supported = group.isTrackSupported(tIdx)
                if (!supported) continue
                counter++
                val langCode = fmt.language.orEmpty()
                val langDisplay = formatLanguageDisplay(langCode, fmt.label)
                val codec = shortAudioCodec(fmt.sampleMimeType, fmt.codecs)
                val layout = channelLayoutLabel(fmt.channelCount)
                val detailParts = listOf(codec, layout).filter { it.isNotBlank() }.joinToString(" • ")
                val fullLabel = if (detailParts.isNotBlank()) "$langDisplay — $detailParts" else "$langDisplay (Track $counter)"
                result.add(
                    VodAudioTrackOption(
                        id = "a_${gIdx}_${tIdx}",
                        label = fullLabel,
                        languageCode = langCode,
                        languageDisplay = langDisplay,
                        codecName = codec,
                        channelLayout = layout,
                        channelCount = fmt.channelCount.coerceAtLeast(0),
                        bitrateBps = fmt.bitrate.coerceAtLeast(0),
                        groupIndex = gIdx,
                        trackIndex = tIdx,
                        isAuto = false,
                        isSupported = true,
                        isSelected = hasManualOverride && group.isTrackSelected(tIdx)
                    )
                )
            }
        }
        return result
    }

    fun selectAudioTrack(player: ExoPlayer, option: VodAudioTrackOption): Boolean {
        val builder = player.trackSelectionParameters.buildUpon()
        if (option.isAuto || option.groupIndex < 0) {
            builder.clearOverridesOfType(C.TRACK_TYPE_AUDIO)
            player.trackSelectionParameters = builder.build()
            return true
        }
        val group = player.currentTracks.groups.getOrNull(option.groupIndex) ?: return false
        if (group.type != C.TRACK_TYPE_AUDIO || option.trackIndex !in 0 until group.length) return false
        if (!group.isTrackSupported(option.trackIndex)) return false
        builder.clearOverridesOfType(C.TRACK_TYPE_AUDIO)
        builder.setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, listOf(option.trackIndex)))
        player.trackSelectionParameters = builder.build()
        return true
    }

    fun inspectSubtitleTracks(player: ExoPlayer): List<VodSubtitleTrackOption> {
        val tracks = player.currentTracks
        val textDisabled = player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
        val result = ArrayList<VodSubtitleTrackOption>()

        var anySelected = false
        val discovered = ArrayList<VodSubtitleTrackOption>()
        var counter = 0
        for ((gIdx, group) in tracks.groups.withIndex()) {
            if (group.type != C.TRACK_TYPE_TEXT) continue
            for (tIdx in 0 until group.length) {
                if (!group.isTrackSupported(tIdx)) continue
                counter++
                val fmt = group.getTrackFormat(tIdx)
                val selected = !textDisabled && group.isTrackSelected(tIdx)
                if (selected) anySelected = true
                val langCode = fmt.language.orEmpty()
                val langDisplay = formatLanguageDisplay(langCode, fmt.label)
                val isExt = (fmt.selectionFlags and C.SELECTION_FLAG_DEFAULT) != 0 && fmt.id?.startsWith("ext_") == true
                val label = if (langDisplay == "Original / Default") "Subtitle Track $counter" else langDisplay
                discovered.add(
                    VodSubtitleTrackOption(
                        id = "s_${gIdx}_${tIdx}",
                        label = if (isExt) "$label (External)" else label,
                        languageCode = langCode,
                        languageDisplay = langDisplay,
                        mimeType = fmt.sampleMimeType.orEmpty(),
                        groupIndex = gIdx,
                        trackIndex = tIdx,
                        isOff = false,
                        isExternal = isExt,
                        isSelected = selected
                    )
                )
            }
        }

        result.add(
            VodSubtitleTrackOption(
                id = "s_off",
                label = "Subtitles Off",
                languageCode = "",
                languageDisplay = "Off",
                mimeType = "",
                groupIndex = -1,
                trackIndex = -1,
                isOff = true,
                isExternal = false,
                isSelected = textDisabled || !anySelected
            )
        )
        result.addAll(discovered)
        return result
    }

    fun selectSubtitleTrack(player: ExoPlayer, option: VodSubtitleTrackOption): Boolean {
        val builder = player.trackSelectionParameters.buildUpon()
        if (option.isOff || option.groupIndex < 0) {
            builder.clearOverridesOfType(C.TRACK_TYPE_TEXT)
            builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            player.trackSelectionParameters = builder.build()
            return true
        }
        val group = player.currentTracks.groups.getOrNull(option.groupIndex) ?: return false
        if (group.type != C.TRACK_TYPE_TEXT || option.trackIndex !in 0 until group.length) return false
        builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
        builder.clearOverridesOfType(C.TRACK_TYPE_TEXT)
        builder.setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, listOf(option.trackIndex)))
        player.trackSelectionParameters = builder.build()
        return true
    }

    fun getCurrentAudioSummary(player: ExoPlayer): String {
        val tracks = player.currentTracks
        for (group in tracks.groups) {
            if (group.type != C.TRACK_TYPE_AUDIO) continue
            for (i in 0 until group.length) {
                if (group.isTrackSelected(i)) {
                    val fmt = group.getTrackFormat(i)
                    val lang = formatLanguageDisplay(fmt.language, fmt.label)
                    val codec = shortAudioCodec(fmt.sampleMimeType, fmt.codecs)
                    return "$lang • $codec"
                }
            }
        }
        return "Default Audio"
    }

    fun getCurrentSubtitleSummary(player: ExoPlayer): String {
        if (player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)) {
            return "Off"
        }
        val tracks = player.currentTracks
        for (group in tracks.groups) {
            if (group.type != C.TRACK_TYPE_TEXT) continue
            for (i in 0 until group.length) {
                if (group.isTrackSelected(i)) {
                    val fmt = group.getTrackFormat(i)
                    return formatLanguageDisplay(fmt.language, fmt.label)
                }
            }
        }
        return "Off"
    }
}
