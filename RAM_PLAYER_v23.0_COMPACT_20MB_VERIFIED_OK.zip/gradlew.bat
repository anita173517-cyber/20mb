@echo off
gradle %*
